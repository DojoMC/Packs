#version 330
#extension GL_ARB_separate_shader_objects : require
#define Ob3 1.0
#define Ob2 0.75
#define Ob1 0.3
#define Ob4 0.25
#define Ob0 0.15
layout(std140) uniform SamplerInfo {
vec2 OutSize;
vec2 InSize;
};
uniform sampler2D InSampler;
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
void main() {
vec2 oneTexel = 1.0 / InSize;
vec3 tintColor = vec3(Ob3, Ob2, Ob1);
vec4 mc = texture(InSampler, texCoord);
if (mc.a > 0.5) {
vec3 tinted = mix(mc.rgb, tintColor, Ob4);
fragColor = vec4(tinted, Ob0);
return;
}
vec4 tl = texture(InSampler, texCoord + vec2(-1.0,  1.0) * oneTexel);
vec4 tc = texture(InSampler, texCoord + vec2( 0.0,  1.0) * oneTexel);
vec4 tr = texture(InSampler, texCoord + vec2( 1.0,  1.0) * oneTexel);
vec4 ml = texture(InSampler, texCoord + vec2(-1.0,  0.0) * oneTexel);
vec4 mr = texture(InSampler, texCoord + vec2( 1.0,  0.0) * oneTexel);
vec4 bl = texture(InSampler, texCoord + vec2(-1.0, -1.0) * oneTexel);
vec4 bc = texture(InSampler, texCoord + vec2( 0.0, -1.0) * oneTexel);
vec4 br = texture(InSampler, texCoord + vec2( 1.0, -1.0) * oneTexel);
float Gx = (-tl.a - 2.0*ml.a - bl.a) + (tr.a + 2.0*mr.a + br.a);
float Gy = (-tl.a - 2.0*tc.a - tr.a) + (bl.a + 2.0*bc.a + br.a);
float edge = sqrt(Gx * Gx + Gy * Gy);
if (edge > 0.3) {
vec4 acc = vec4(0.0);
float w = 0.0;
if (tl.a > 0.5) { acc += tl; w += 1.0; }
if (tc.a > 0.5) { acc += tc; w += 1.0; }
if (tr.a > 0.5) { acc += tr; w += 1.0; }
if (ml.a > 0.5) { acc += ml; w += 1.0; }
if (mr.a > 0.5) { acc += mr; w += 1.0; }
if (bl.a > 0.5) { acc += bl; w += 1.0; }
if (bc.a > 0.5) { acc += bc; w += 1.0; }
if (br.a > 0.5) { acc += br; w += 1.0; }
if (w > 0.0) {
vec3 edgeColor = mix((acc / w).rgb, tintColor, Ob4);
fragColor = vec4(edgeColor, 1.0);
} else {
fragColor = vec4(0.0);
}
} else {
fragColor = vec4(0.0);
}
}
