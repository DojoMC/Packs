#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#include <event:game_border.glsl>
#include <event:cinematic_fx.glsl>
#include <event:grenade_fx.glsl>
uniform sampler2D Sampler0;
#ifdef GLINT
uniform sampler2D GlintSampler;
#endif
#ifndef OIT_ALPHA_ONLY
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif
layout(location = 2) in vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) in vec4 lightMapColor;
layout(location = 4) in vec4 overlayColor;
#endif
layout(location = 5) in vec2 texCoord0;
#ifdef GLINT
layout(location = 6) in vec2 texCoordGlint;
#endif
layout(location = 7) in vec3 borderView;
layout(location = 8) flat in vec3 borderTint;
layout(location = 9) flat in vec3 borderNormal;
layout(location = 10) flat in ivec2 grenadeLight;
#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif
#ifndef OIT_ALPHA_ONLY
vec4 Od7(vec4 color, float sphericalDistance, float cylindricalDistance) {
#ifdef OIT_ACCUMULATE
color = sampleColorForAccumulation(color);
vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
#else
vec4 fogColor = FogColor;
#endif
return apply_fog(color, sphericalDistance, cylindricalDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}
vec4 Oc6(vec4 color) {
color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
color *= lightMapColor;
#ifdef GLINT
vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);
color.rgb += glintColor.rgb * glintColor.rgb;
#endif
return Od7(color, sphericalVertexDistance, cylindricalVertexDistance);
}
#endif
void main() {
BorderDerivatives borderDerivatives = Obb(texCoord0, vec2(textureSize(Sampler0, 0)), borderView);
vec4 color = texture(Sampler0, texCoord0);
#ifdef ALPHA_CUTOUT
if (color.a < ALPHA_CUTOUT) {
discard;
}
#endif
vec4 borderTexel = textureLod(Sampler0, texCoord0, 0.0);
float fragDepth = gl_FragCoord.z;
vec3 fogView = borderView;
int borderFlags = Obd(borderTexel);
int cinematicKind = Oce(borderTexel);
int grenadeKind = Oec(borderTexel);
bool border = borderFlags >= 0;
bool cinematic = cinematicKind >= 0;
bool grenade = grenadeKind >= 0;
if (border) {
if (Oba(borderDerivatives, borderNormal, borderView)) {
discard;
}
vec2 panel = Oc2(borderTexel, texCoord0, vec2(textureSize(Sampler0, 0)));
vec3 worldPos = Oc5(borderView);
color = Obc(borderFlags, panel, borderDerivatives, worldPos, borderNormal, borderTint, length(borderView), GameTime * 1200.0);
if (color.a <= 0.0) {
discard;
}
color.a *= ColorModulator.a;
} else if (cinematic) {
vec2 panel = Oc2(borderTexel, texCoord0, vec2(textureSize(Sampler0, 0)));
color = Od1(cinematicKind, panel, borderDerivatives, borderView, borderTint, GameTime * 1200.0);
if (color.a <= 0.0) {
discard;
}
color.a *= ColorModulator.a;
} else if (grenade) {
if (grenadeKind >= O2d) {
vec3 hit;
color = Of0(grenadeKind, borderView, borderTint, grenadeLight, hit);
fragDepth = Oe6(hit, borderView, gl_FragCoord.z);
fogView = hit;
} else {
vec2 panel = Oc2(borderTexel, texCoord0, vec2(textureSize(Sampler0, 0)));
color = Oe7(grenadeKind, panel, borderTint);
}
if (color.a <= 0.0) {
discard;
}
color.a *= ColorModulator.a;
} else {
color *= vertexColor * ColorModulator;
#ifdef GLINT
color.a = max(color.a, GlintAlpha);
#endif
}
#ifdef OIT_ALPHA_ONLY
executeAlphaOnlyPhase(fragDepth, color.a);
#else
if (cinematicKind == O15) {
fogView = vec3(0.0);
}
fragColor = border || cinematic || grenade
? Od7(color, fog_spherical_distance(fogView), fog_cylindrical_distance(fogView))
: Oc6(color);
#endif
gl_FragDepth = fragDepth;
}
