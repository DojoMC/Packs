#ifndef O23
#define O23
#define O99 248
#define O9a 252
#define O98 48.0
#define O8c 1
#define O8d 2
#define O90 3
#define O8e 4
#define Oa7 5
#define Oa9 6
#define Oaa 7
#define Oaf 8
#define Oae 9
#define Oa0 10
#define O92 16
#define O9b 16
#define O9e 11
#define O9f 15
#define Oa6 6.0
#define O9c 64.0
const float TFX_INTENSITY[4] = float[4](0.45, 1.0, 1.6, 2.4);
#define Oad 32
#ifdef O8f
#define O9d 3.14159265359
#define Oa5 3.5
#define Oa8 vec3(0.96, 0.95, 0.92)
struct TfxGlyph {
vec2 tl;
vec2 br;
vec2 p;
vec2 origin;
vec2 size;
float u;
};
float O130(vec2 p) {
vec3 p3 = fract(vec3(p.xyx) * 0.1031);
p3 += dot(p3, p3.yzx + 33.33);
return fract((p3.x + p3.y) * p3.z);
}
float O12c(float x) {
return 1.0 - pow(1.0 - x, 3.0);
}
float O12a(float x) {
float c1 = 2.2;
float c3 = c1 + 1.0;
return 1.0 + c3 * pow(x - 1.0, 3.0) + c1 * pow(x - 1.0, 2.0);
}
float O12b(float x) {
if (x < 1.0 / 2.75) return 7.5625 * x * x;
if (x < 2.0 / 2.75) { x -= 1.5 / 2.75; return 7.5625 * x * x + 0.75; }
if (x < 2.5 / 2.75) { x -= 2.25 / 2.75; return 7.5625 * x * x + 0.9375; }
x -= 2.625 / 2.75;
return 7.5625 * x * x + 0.984375;
}
vec4 O135(vec4 top, vec4 bottom) {
float a = top.a + bottom.a * (1.0 - top.a);
if (a <= 0.0) return vec4(0.0);
return vec4((top.rgb * top.a + bottom.rgb * bottom.a * (1.0 - top.a)) / a, a);
}
bool O12e(vec2 p, vec3 topLeft, vec3 bottomRight, vec2 origin, vec2 size, vec2 bottomRightTexel, out TfxGlyph g) {
float packedHeight = floor(size.y + 0.5);
float paddingRows = floor(packedHeight / O9c);
g.p = p;
g.origin = floor(origin + 0.5);
g.size = vec2(floor(size.x + 0.5), packedHeight - paddingRows * O9c);
g.tl = vec2(0.0);
g.br = vec2(0.0);
g.u = 1.0;
if (topLeft.z <= 1e-5 || bottomRight.z <= 1e-5) return false;
g.size = min(g.size, floor(bottomRightTexel - g.origin + 0.5));
if (any(lessThan(g.size, vec2(1.0)))) return false;
vec2 quadTopLeft = topLeft.xy / topLeft.z;
vec2 quadBottomRight = bottomRight.xy / bottomRight.z;
float quadRows = floor(bottomRightTexel.y - (g.origin.y - paddingRows) + 0.5);
if (quadRows < 1.0) return false;
g.u = (quadBottomRight.y - quadTopLeft.y) / quadRows;
g.tl = quadTopLeft + vec2(0.0, paddingRows * g.u);
g.br = g.tl + g.size * g.u;
return g.u > 0.0;
}
vec4 O140(TfxGlyph g, vec2 q) {
vec2 cell = floor((q - g.tl) / g.u);
if (any(lessThan(cell, vec2(0.0))) || any(greaterThanEqual(cell, g.size))) return vec4(0.0);
return texelFetch(Sampler0, ivec2(g.origin + cell), 0);
}
float O12f(TfxGlyph g) {
return floor(g.tl.x * 4.0 + 0.5);
}
float O126(TfxGlyph g, vec2 q) {
return step(0.1, O140(g, q).a);
}
float O127(TfxGlyph g, vec2 q, float r) {
return max(
max(O126(g, q + vec2(r, 0.0)), O126(g, q - vec2(r, 0.0))),
max(O126(g, q + vec2(0.0, r)), O126(g, q - vec2(0.0, r)))
);
}
vec4 O136(TfxGlyph g, vec2 q, vec3 colour, vec4 shadow) {
vec4 texel = O140(g, q);
vec4 body = vec4(colour * texel.rgb, step(0.1, texel.a));
return O135(body, vec4(shadow.rgb, shadow.a * O126(g, q - vec2(g.u))));
}
vec2 O13a(TfxGlyph g, vec2 gui, float scale) {
vec2 anchor = vec2(gui.x * 0.5, (g.tl.y + g.br.y) * 0.5);
return anchor + (g.p - anchor) / scale;
}
float O13b(vec2 p, vec2 gui, float u, float time) {
float x = (fract(time / Oa5) * 1.8 - 0.4) * gui.x;
float d = p.x + (p.y - gui.y * 0.5) * 0.5 - x;
return exp(-pow(d / (4.0 * u), 2.0));
}
vec4 O134(TfxGlyph g, vec2 q, vec3 colour) {
vec4 texel = O140(g, q);
float shade = mix(1.12, 0.88, clamp((q.y - g.tl.y) / (g.br.y - g.tl.y), 0.0, 1.0));
vec4 body = vec4(clamp(colour * texel.rgb * shade, 0.0, 1.0), step(0.1, texel.a));
return O135(body, vec4(colour * 0.25, O126(g, q - vec2(g.u))));
}
vec4 O123(TfxGlyph g, vec3 colour, float time, float strength) {
float u = g.u;
float hop = abs(sin(time * 6.5 - g.tl.x / u * 0.32));
float contact = 1.0 - smoothstep(0.0, 0.4, hop);
vec2 squash = vec2(1.0 + 0.1 * contact * strength, 1.0 - 0.14 * contact * min(strength, 2.0));
float base = g.br.y;
float centre = (g.tl.x + g.br.x) * 0.5;
vec2 q = g.p + vec2(0.0, hop * 2.5 * u * strength);
q = vec2(centre + (q.x - centre) / squash.x, base - (base - q.y) / squash.y);
return O134(g, q, colour);
}
vec4 O141(TfxGlyph g, vec3 colour, float time, float strength) {
float u = g.u;
float phase = time * 4.0 - g.tl.x / u * 0.28;
float rise = sin(phase) * 1.8 * u * strength;
float lean = cos(phase) * 0.12 * strength;
vec2 centre = (g.tl + g.br) * 0.5;
vec2 q = g.p + vec2(0.0, rise);
q.x += (q.y - centre.y) * lean;
return O134(g, q, colour);
}
vec4 O142(TfxGlyph g, vec3 colour, float time, float strength) {
float u = g.u;
float seed = O12f(g);
float angle = (sin(time * 9.0 + seed * 1.7) * 0.2 + sin(time * 23.0 + seed * 3.1) * 0.04) * strength;
vec2 centre = (g.tl + g.br) * 0.5;
vec2 d = g.p - centre;
float c = cos(angle);
float s = sin(angle);
vec2 q = centre + vec2(c * d.x + s * d.y, -s * d.x + c * d.y);
return O134(g, q, colour);
}
#define Oa3 0.05
#define Oa4 15.0
#define Oa1 5.0
#define Oa2 2.0
vec4 O138(TfxGlyph g, vec3 colour, float time, float strength) {
float u = g.u;
float centre = (g.tl.x + g.br.x) * 0.5 / u;
float phase = mod(centre * Oa3 - time * Oa4, Oa1 * 2.0 * O9d);
float swell = phase < 2.0 * O9d ? 0.5 - 0.5 * cos(phase) : 0.0;
return O134(g, g.p + vec2(0.0, swell * Oa2 * u * strength), colour);
}
vec4 O125(TfxGlyph g, vec3 colour, float a, vec2 gui, float time) {
float u = g.u;
float settled = a * a * a * a;
float scale = mix(2.6, 1.0, O12a(a)) * (1.0 + 0.035 * sin(time * O9d * 4.0) * settled);
vec2 q = O13a(g, gui, scale);
float heat = pow(1.0 - a, 1.4);
vec3 tone = mix(colour, vec3(1.0), heat);
float glow = 0.0;
for (int i = 0; i < 8; i++) {
float angle = float(i) * O9d * 0.25;
vec2 d = vec2(cos(angle), sin(angle)) * u;
glow += O126(g, q + d * 1.5) * 0.6 + O126(g, q + d * 3.0) * 0.4;
}
glow /= 8.0;
float pulse = 0.4 + 0.15 * sin(time * O9d * 4.0);
vec4 halo = vec4(mix(colour, vec3(1.0), 0.35 + 0.65 * heat), glow * (pulse + 0.7 * heat));
vec4 letter = O136(g, q, tone, vec4(colour * 0.25, 1.0));
vec4 result = O135(letter, halo);
result.a *= smoothstep(0.0, 0.35, a);
return result;
}
#define O91 0.45
vec4 O12d(TfxGlyph g, vec3 colour, vec2 gui, float time) {
vec3 tone = clamp(colour + O13b(g.p, gui, g.u, time - O91) * 0.45, 0.0, 1.0);
return O136(g, g.p, tone, vec4(colour * 0.25, 1.0));
}
float O124(TfxGlyph g, float x) {
float rows = floor((g.br.y - g.tl.y) / g.u + 0.5);
for (int i = 0; i < 32; i++) {
float row = rows - 1.0 - float(i);
if (row < 0.0) break;
if (O126(g, vec2(x, g.tl.y + (row + 0.5) * g.u)) > 0.0) return row;
}
return -1.0;
}
float O129(TfxGlyph g, vec2 q, float grown, float time) {
float u = g.u;
float column = floor((q.x - g.tl.x) / u);
float x = g.tl.x + (column + 0.5) * u;
if (x < g.tl.x || x > g.br.x) return 0.0;
vec2 seed = vec2(column, O12f(g));
float chance = O130(seed);
if (chance < 0.55) return 0.0;
float bottom = O124(g, x);
if (bottom < 0.0) return 0.0;
float start = g.tl.y + (bottom + 1.0) * u;
float span = (1.0 + O130(seed + 3.1) * 4.0) * grown * (0.85 + 0.15 * sin(time * 1.3 + chance * 6.0));
float below = floor((q.y - start) / u);
return below >= 0.0 && below < floor(span + 0.5) ? 1.0 : 0.0;
}
vec4 O128(TfxGlyph g, vec3 colour, float a, vec2 gui, float time) {
float u = g.u;
float seed = O12f(g);
float frame = floor(time * 24.0);
vec2 shake = (vec2(O130(vec2(frame, seed)), O130(vec2(seed, frame + 3.7))) - 0.5) * (0.3 + 4.0 * (1.0 - a)) * u;
vec2 q = O13a(g, gui, mix(1.8, 1.0, O12c(a))) + shake;
float burst = floor(time * 9.0);
float glitch = step(0.84, O130(vec2(burst, 4.2)));
q.x += glitch * (O130(vec2(floor(g.p.y / (2.0 * u)), burst)) - 0.5) * 5.0 * u;
float shown = smoothstep(0.0, 0.7, a) * 1.05;
if (O130(floor((q - g.tl) / u) + seed * 7.0) > shown) return vec4(0.0);
float v = clamp((q.y - g.tl.y) / (g.br.y - g.tl.y), 0.0, 1.0);
vec3 tone = mix(clamp(colour * 1.1 + 0.08, 0.0, 1.0), colour * 0.5, v);
tone = mix(tone, vec3(1.0, 0.86, 0.86), pow(1.0 - a, 3.0));
float grown = smoothstep(0.3, 1.0, a);
float body = O126(g, q);
float drip = body > 0.0 ? 0.0 : O129(g, q, grown, time);
vec4 result = vec4(body > 0.0 ? tone : colour * 0.45, max(body, drip));
if (glitch > 0.0) {
vec4 cyan = vec4(0.1, 0.9, 0.9, O126(g, q + vec2(1.5 * u, 0.0)) * 0.5);
vec4 red = vec4(1.0, 0.1, 0.15, O126(g, q - vec2(1.5 * u, 0.0)) * 0.5);
result = O135(result, O135(red, cyan));
}
float shadow = max(O126(g, q - vec2(u)), body > 0.0 ? 0.0 : O129(g, q - vec2(u), grown, time));
return O135(result, vec4(0.08, 0.0, 0.0, shadow * 0.8));
}
#define Oac 0.45
#define Oab 2.5
float O13f(float a, vec2 gui, float u, float span, float y) {
float lean = 5.0 * u * Oac;
float reach = span > 0.0 ? span * u * 0.5 : gui.x * 0.5 + O98;
float start = gui.x * 0.5 - reach - lean;
float travel = 2.0 * (reach + lean) + Oab * 2.0 * u;
float titleMiddle = gui.y * 0.5 - 7.0 * u;
return start + smoothstep(0.0, 1.0, a) * travel + (titleMiddle - y) * Oac;
}
vec4 O139(float across) {
float shade = 0.62 + 0.38 * sin(across * O9d);
shade += 0.3 * exp(-pow((across - 0.32) / 0.09, 2.0));
float rim = smoothstep(0.0, 0.1, across) * (1.0 - smoothstep(0.9, 1.0, across));
return vec4(clamp(Oa8 * shade * mix(0.7, 1.0, rim), 0.0, 1.0), 1.0);
}
bool O13d(TfxGlyph g, vec2 p, bool plate) {
if (p.x >= g.tl.x && p.x < g.br.x) return true;
return !plate && p.x >= g.tl.x - g.u && p.x < g.tl.x;
}
vec4 O13c(TfxGlyph g, vec3 colour, float a, vec2 gui, float time, bool plate, float span) {
float u = g.u;
vec2 p = g.p;
if (!O13d(g, p, plate)) return vec4(0.0);
float line = O13f(a, gui, u, span, p.y);
if (p.x >= line) {
float across = (p.x - line) / (2.0 * Oab * u);
bool shaped = plate ? O126(g, p) > 0.0 : p.y >= g.tl.y && p.y < g.br.y;
return across < 1.0 && shaped ? O139(across) : vec4(0.0);
}
float body = O126(g, p);
float edge = plate ? 0.0 : O127(g, p, u) * (1.0 - body);
float shine = O13b(p, gui, u, time);
vec3 face = colour + shine * 0.22;
vec3 rim = Oa8 + shine * 0.04;
vec4 result = vec4(clamp(body > 0.0 ? face : rim, 0.0, 1.0), max(body, edge));
if (!plate) {
vec2 dropped = p - vec2(0.0, 1.5 * u);
float shadow = max(O126(g, dropped), O127(g, dropped, u)) * 0.38;
result = O135(result, vec4(0.0, 0.0, 0.0, shadow));
}
result.rgb *= 1.0 - 0.3 * exp(-(line - p.x) / (1.5 * u));
return result;
}
vec4 O13e(TfxGlyph g, vec3 colour, float a, vec2 gui, float time, float span) {
if (g.p.x >= O13f(a, gui, g.u, span, g.p.y) || g.p.x < g.tl.x || g.p.x >= g.br.x + g.u) return vec4(0.0);
vec3 tone = colour + O13b(g.p, gui, g.u, time) * 0.22;
vec4 texel = O140(g, g.p);
return vec4(clamp(tone * texel.rgb, 0.0, 1.0), step(0.1, texel.a));
}
#define O96 vec3(1.0, 0.96, 0.52)
#define O95 vec3(1.0, 0.72, 0.0)
#define O97 vec3(1.0)
#define O94 1.5
#define O93 1.5
vec4 O132(TfxGlyph g, vec2 q, float edge, float sung) {
vec4 texel = O140(g, q);
float body = step(0.1, texel.a);
float v = clamp((q.y - g.tl.y) / max(g.br.y - g.tl.y, 1e-5), 0.0, 1.0);
vec3 gold = mix(O96, O95, v);
vec3 white = O97 * mix(1.0, 0.86, v);
float wipe = clamp((edge - q.x) / (O93 * g.u) + 0.5, 0.0, 1.0) * sung;
return vec4(mix(white, gold, wipe) * texel.rgb, body);
}
vec4 O131(TfxGlyph g, float a, vec2 gui, float time, float extra) {
float fill = extra / 255.0;
float u = g.u;
float singing = fill > 0.0 && fill < 1.0 ? 1.0 : 0.0;
float lift = sin(fill * O9d) * O94 * u * singing;
vec2 q = g.p + vec2(0.0, lift);
float width = g.br.x - g.tl.x;
float edge = g.tl.x + fill * width;
float sung = fill > 0.0 ? 1.0 : 0.0;
vec4 letter = O132(g, q, edge, sung);
float shine = O13b(q, gui, u, time) * sung * step(q.x, edge);
letter.rgb = clamp(letter.rgb + shine * 0.25, 0.0, 1.0);
float halo = O127(g, q, u) * (1.0 - letter.a) * step(q.x, edge + u) * sung;
float pulse = 0.22 + 0.12 * singing * (0.5 + 0.5 * sin(time * 9.0));
vec4 glow = vec4(O95, halo * pulse);
vec2 dropped = q - vec2(u);
vec3 shadowTone = mix(vec3(0.24), O95 * 0.25, step(dropped.x, edge) * sung);
vec4 shadow = vec4(shadowTone, O126(g, dropped));
vec4 result = O135(letter, O135(shadow, glow));
result.a *= a;
return result;
}
vec4 O137(int style, TfxGlyph g, vec3 colour, float a, vec2 gui, float time, float extra) {
int effect = style - Oad;
a = clamp(a, 0.0, 1.0);
vec4 result = vec4(0.0);
if (effect == O8c || effect == Oae || effect == Oaf || effect == Oa0) {
float strength = TFX_INTENSITY[clamp(int(extra + 0.5), 0, 3)];
if (effect == O8c) result = O123(g, colour, time, strength);
else if (effect == Oae) result = O141(g, colour, time, strength);
else if (effect == Oaf) result = O142(g, colour, time, strength);
else result = O138(g, colour, time, strength);
result.a *= a;
} else if (effect == O8d) {
result = O125(g, colour, a, gui, time);
} else if (effect == O90) {
result = O12d(g, colour, gui, time);
result.a *= a;
} else if (effect == O8e) {
result = O128(g, colour, a, gui, time);
} else if (effect == Oa7) {
result = O13c(g, colour, a, gui, time, false, 0.0);
} else if (effect == Oa9) {
result = O13c(g, colour, a, gui, time, true, extra);
} else if (effect == Oaa) {
result = O13e(g, colour, a, gui, time, extra);
} else if (effect == O92) {
result = O131(g, a, gui, time, extra);
}
return result;
}
#endif
#endif
