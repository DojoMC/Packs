#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
#include <event:post_common.glsl>
uniform sampler2D ClockSampler;
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
void main() {
vec4 clock = texture(ClockSampler, vec2(0.5));
fragColor = clock.a < 0.5 ? vec4(Oda(GameTime), 1.0) : clock;
}
