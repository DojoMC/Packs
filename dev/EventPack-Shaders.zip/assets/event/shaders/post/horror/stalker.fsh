#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
#include <event:horror.glsl>
#define O82 10.0
#define O81 48.0
uniform sampler2D InSampler;
uniform sampler2D DepthSampler;
layout(std140) uniform SamplerInfo {
vec2 OutSize;
vec2 InSize;
vec2 DepthSize;
};
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
void main() {
vec3 scene = texture(InSampler, texCoord).rgb;
float dist = Of3(texture(DepthSampler, texCoord).r);
float luma = Ode(scene);
vec3 color = vec3(luma) * vec3(1.05, 0.78, 0.66);
color = pow(max(color, 0.0), vec3(1.15));
color *= 1.0 - 0.7 * smoothstep(O82, O81, dist);
float saturation = max(scene.r, max(scene.g, scene.b)) - min(scene.r, min(scene.g, scene.b));
color = mix(color, scene, smoothstep(0.6, 0.8, saturation) * step(0.3, luma));
float breath = 0.5 + 0.5 * sin(Oe1() * 1.1);
color *= mix(0.3, 1.0, Oe4(texCoord, OutSize, 0.28 + 0.03 * breath, 0.95));
color = Odb(color, floor(texCoord * OutSize), 0.04);
fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
