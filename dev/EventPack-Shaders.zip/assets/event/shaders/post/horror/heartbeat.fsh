#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
#include <event:horror.glsl>
uniform sampler2D InSampler;
layout(std140) uniform SamplerInfo {
vec2 OutSize;
vec2 InSize;
};
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
void main() {
float beat = Of4();
vec2 uv = 0.5 + (texCoord - 0.5) * (1.0 - 0.018 * beat);
vec3 color = Oe2(InSampler, uv, (uv - 0.5) * 0.012 * beat);
float rim = 1.0 - Oe4(texCoord, OutSize, 0.25, 0.85);
float blood = rim * (0.30 + 0.60 * beat);
color = mix(color, vec3(0.42, 0.0, 0.03) * (0.6 + 0.4 * Ode(color)), clamp(blood, 0.0, 1.0));
color *= 1.0 - 0.15 * beat * rim;
fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
