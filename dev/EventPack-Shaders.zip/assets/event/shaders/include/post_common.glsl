#ifndef O22
#define O22
#define O24 3.14159265359
float Oe3() {
return GameTime * 24000.0;
}
float Oe1() {
return GameTime * 1200.0;
}
float Odc(vec2 p) {
vec3 p3 = fract(vec3(p.xyx) * 0.1031);
p3 += dot(p3, p3.yzx + 33.33);
return fract((p3.x + p3.y) * p3.z);
}
float Odd(float x) {
return Odc(vec2(x, x * 1.618));
}
float Odf(float x) {
float i = floor(x);
float f = fract(x);
return mix(Odd(i), Odd(i + 1.0), f * f * (3.0 - 2.0 * f));
}
float Ode(vec3 c) {
return dot(c, vec3(0.2126, 0.7152, 0.0722));
}
vec3 Oe0(vec3 c, float amount) {
return mix(vec3(Ode(c)), c, amount);
}
float Oe4(vec2 uv, vec2 size, float inner, float outer) {
vec2 d = (uv - 0.5) * vec2(size.x / size.y, 1.0);
return 1.0 - smoothstep(inner, outer, length(d));
}
vec3 Odb(vec3 c, vec2 pixel, float amount) {
float frame = floor(Oe1() * 24.0);
float n = Odc(pixel + frame * vec2(17.0, 59.0)) - 0.5;
return c + n * amount;
}
vec3 Oe2(sampler2D image, vec2 uv, vec2 offset) {
return vec3(
texture(image, uv + offset).r,
texture(image, uv).g,
texture(image, uv - offset).b
);
}
vec3 Oda(float t) {
float v = floor(clamp(t, 0.0, 1.0) * 16777215.0);
float r = floor(v / 65536.0);
float g = floor((v - r * 65536.0) / 256.0);
float b = v - r * 65536.0 - g * 256.0;
return vec3(r, g, b) / 255.0;
}
float Od8(vec3 rgb) {
vec3 bytes = floor(rgb * 255.0 + 0.5);
return (bytes.r * 65536.0 + bytes.g * 256.0 + bytes.b) / 16777215.0;
}
float Od9(vec4 clock) {
return fract(GameTime - Od8(clock.rgb) + 1.0) * 1200.0;
}
#endif
