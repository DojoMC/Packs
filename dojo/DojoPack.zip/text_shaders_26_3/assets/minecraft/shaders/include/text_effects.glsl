#ifndef O2
#define O2
#define O3b 248
#define O3c 252
#define O3a 48.0
#define O2e 1
#define O2f 2
#define O32 3
#define O30 4
#define O49 5
#define O4b 6
#define O4c 7
#define O51 8
#define O50 9
#define O42 10
#define O34 16
#define O3d 16
#define O40 11
#define O41 15
#define O48 6.0
#define O3e 64.0
const float TFX_INTENSITY[4] = float[4](0.45, 1.0, 1.6, 2.4);
#define O4f 32
#ifdef O31
#define O3f 3.14159265359
#define O47 3.5
#define O4a vec3(0.96, 0.95, 0.92)
struct TfxGlyph {
vec2 tl;
vec2 br;
vec2 p;
vec2 origin;
vec2 size;
float u;
};
float O89(vec2 p) {
vec3 p3 = fract(vec3(p.xyx) * 0.1031);
p3 += dot(p3, p3.yzx + 33.33);
return fract((p3.x + p3.y) * p3.z);
}
float O85(float x) {
return 1.0 - pow(1.0 - x, 3.0);
}
float O83(float x) {
float c1 = 2.2;
float c3 = c1 + 1.0;
return 1.0 + c3 * pow(x - 1.0, 3.0) + c1 * pow(x - 1.0, 2.0);
}
float O84(float x) {
if (x < 1.0 / 2.75) return 7.5625 * x * x;
if (x < 2.0 / 2.75) { x -= 1.5 / 2.75; return 7.5625 * x * x + 0.75; }
if (x < 2.5 / 2.75) { x -= 2.25 / 2.75; return 7.5625 * x * x + 0.9375; }
x -= 2.625 / 2.75;
return 7.5625 * x * x + 0.984375;
}
vec4 O8e(vec4 top, vec4 bottom) {
float a = top.a + bottom.a * (1.0 - top.a);
if (a <= 0.0) return vec4(0.0);
return vec4((top.rgb * top.a + bottom.rgb * bottom.a * (1.0 - top.a)) / a, a);
}
bool O87(vec2 p, vec3 topLeft, vec3 bottomRight, vec2 origin, vec2 size, vec2 bottomRightTexel, out TfxGlyph g) {
float packedHeight = floor(size.y + 0.5);
float paddingRows = floor(packedHeight / O3e);
g.p = p;
g.origin = floor(origin + 0.5);
g.size = vec2(floor(size.x + 0.5), packedHeight - paddingRows * O3e);
g.tl = vec2(0.0);
g.br = vec2(0.0);
g.u = 1.0;
if (topLeft.z <= 1e-5 || bottomRight.z <= 1e-5) return false;
g.size = min(g.size, floor(bottomRightTexel - g.origin + 0.5));
if (any(lessThan(g.size, vec2(1.0)))) return false;
vec2 quadTopLeft = topLeft.xy / topLeft.z;
vec2 quadBottomRight = bottomRight.xy / bottomRight.z;
float quadRows = floor(bottomRightTexel.y - (g.origin.y - paddingRows) + 0.5);
if (quadRows < 1.0) return false;
g.u = (quadBottomRight.y - quadTopLeft.y) / quadRows;
g.tl = quadTopLeft + vec2(0.0, paddingRows * g.u);
g.br = g.tl + g.size * g.u;
return g.u > 0.0;
}
vec4 O99(TfxGlyph g, vec2 q) {
vec2 cell = floor((q - g.tl) / g.u);
if (any(lessThan(cell, vec2(0.0))) || any(greaterThanEqual(cell, g.size))) return vec4(0.0);
return texelFetch(Sampler0, ivec2(g.origin + cell), 0);
}
float O88(TfxGlyph g) {
return floor(g.tl.x * 4.0 + 0.5);
}
float O7f(TfxGlyph g, vec2 q) {
return step(0.1, O99(g, q).a);
}
float O80(TfxGlyph g, vec2 q, float r) {
return max(
max(O7f(g, q + vec2(r, 0.0)), O7f(g, q - vec2(r, 0.0))),
max(O7f(g, q + vec2(0.0, r)), O7f(g, q - vec2(0.0, r)))
);
}
vec4 O8f(TfxGlyph g, vec2 q, vec3 colour, vec4 shadow) {
vec4 texel = O99(g, q);
vec4 body = vec4(colour * texel.rgb, step(0.1, texel.a));
return O8e(body, vec4(shadow.rgb, shadow.a * O7f(g, q - vec2(g.u))));
}
vec2 O93(TfxGlyph g, vec2 gui, float scale) {
vec2 anchor = vec2(gui.x * 0.5, (g.tl.y + g.br.y) * 0.5);
return anchor + (g.p - anchor) / scale;
}
float O94(vec2 p, vec2 gui, float u, float time) {
float x = (fract(time / O47) * 1.8 - 0.4) * gui.x;
float d = p.x + (p.y - gui.y * 0.5) * 0.5 - x;
return exp(-pow(d / (4.0 * u), 2.0));
}
vec4 O8d(TfxGlyph g, vec2 q, vec3 colour) {
vec4 texel = O99(g, q);
float shade = mix(1.12, 0.88, clamp((q.y - g.tl.y) / (g.br.y - g.tl.y), 0.0, 1.0));
vec4 body = vec4(clamp(colour * texel.rgb * shade, 0.0, 1.0), step(0.1, texel.a));
return O8e(body, vec4(colour * 0.25, O7f(g, q - vec2(g.u))));
}
vec4 O7c(TfxGlyph g, vec3 colour, float time, float strength) {
float u = g.u;
float hop = abs(sin(time * 6.5 - g.tl.x / u * 0.32));
float contact = 1.0 - smoothstep(0.0, 0.4, hop);
vec2 squash = vec2(1.0 + 0.1 * contact * strength, 1.0 - 0.14 * contact * min(strength, 2.0));
float base = g.br.y;
float centre = (g.tl.x + g.br.x) * 0.5;
vec2 q = g.p + vec2(0.0, hop * 2.5 * u * strength);
q = vec2(centre + (q.x - centre) / squash.x, base - (base - q.y) / squash.y);
return O8d(g, q, colour);
}
vec4 O9a(TfxGlyph g, vec3 colour, float time, float strength) {
float u = g.u;
float phase = time * 4.0 - g.tl.x / u * 0.28;
float rise = sin(phase) * 1.8 * u * strength;
float lean = cos(phase) * 0.12 * strength;
vec2 centre = (g.tl + g.br) * 0.5;
vec2 q = g.p + vec2(0.0, rise);
q.x += (q.y - centre.y) * lean;
return O8d(g, q, colour);
}
vec4 O9b(TfxGlyph g, vec3 colour, float time, float strength) {
float u = g.u;
float seed = O88(g);
float angle = (sin(time * 9.0 + seed * 1.7) * 0.2 + sin(time * 23.0 + seed * 3.1) * 0.04) * strength;
vec2 centre = (g.tl + g.br) * 0.5;
vec2 d = g.p - centre;
float c = cos(angle);
float s = sin(angle);
vec2 q = centre + vec2(c * d.x + s * d.y, -s * d.x + c * d.y);
return O8d(g, q, colour);
}
#define O45 0.05
#define O46 15.0
#define O43 5.0
#define O44 2.0
vec4 O91(TfxGlyph g, vec3 colour, float time, float strength) {
float u = g.u;
float centre = (g.tl.x + g.br.x) * 0.5 / u;
float phase = mod(centre * O45 - time * O46, O43 * 2.0 * O3f);
float swell = phase < 2.0 * O3f ? 0.5 - 0.5 * cos(phase) : 0.0;
return O8d(g, g.p + vec2(0.0, swell * O44 * u * strength), colour);
}
vec4 O7e(TfxGlyph g, vec3 colour, float a, vec2 gui, float time) {
float u = g.u;
float settled = a * a * a * a;
float scale = mix(2.6, 1.0, O83(a)) * (1.0 + 0.035 * sin(time * O3f * 4.0) * settled);
vec2 q = O93(g, gui, scale);
float heat = pow(1.0 - a, 1.4);
vec3 tone = mix(colour, vec3(1.0), heat);
float glow = 0.0;
for (int i = 0; i < 8; i++) {
float angle = float(i) * O3f * 0.25;
vec2 d = vec2(cos(angle), sin(angle)) * u;
glow += O7f(g, q + d * 1.5) * 0.6 + O7f(g, q + d * 3.0) * 0.4;
}
glow /= 8.0;
float pulse = 0.4 + 0.15 * sin(time * O3f * 4.0);
vec4 halo = vec4(mix(colour, vec3(1.0), 0.35 + 0.65 * heat), glow * (pulse + 0.7 * heat));
vec4 letter = O8f(g, q, tone, vec4(colour * 0.25, 1.0));
vec4 result = O8e(letter, halo);
result.a *= smoothstep(0.0, 0.35, a);
return result;
}
#define O33 0.45
vec4 O86(TfxGlyph g, vec3 colour, vec2 gui, float time) {
vec3 tone = clamp(colour + O94(g.p, gui, g.u, time - O33) * 0.45, 0.0, 1.0);
return O8f(g, g.p, tone, vec4(colour * 0.25, 1.0));
}
float O7d(TfxGlyph g, float x) {
float rows = floor((g.br.y - g.tl.y) / g.u + 0.5);
for (int i = 0; i < 32; i++) {
float row = rows - 1.0 - float(i);
if (row < 0.0) break;
if (O7f(g, vec2(x, g.tl.y + (row + 0.5) * g.u)) > 0.0) return row;
}
return -1.0;
}
float O82(TfxGlyph g, vec2 q, float grown, float time) {
float u = g.u;
float column = floor((q.x - g.tl.x) / u);
float x = g.tl.x + (column + 0.5) * u;
if (x < g.tl.x || x > g.br.x) return 0.0;
vec2 seed = vec2(column, O88(g));
float chance = O89(seed);
if (chance < 0.55) return 0.0;
float bottom = O7d(g, x);
if (bottom < 0.0) return 0.0;
float start = g.tl.y + (bottom + 1.0) * u;
float span = (1.0 + O89(seed + 3.1) * 4.0) * grown * (0.85 + 0.15 * sin(time * 1.3 + chance * 6.0));
float below = floor((q.y - start) / u);
return below >= 0.0 && below < floor(span + 0.5) ? 1.0 : 0.0;
}
vec4 O81(TfxGlyph g, vec3 colour, float a, vec2 gui, float time) {
float u = g.u;
float seed = O88(g);
float frame = floor(time * 24.0);
vec2 shake = (vec2(O89(vec2(frame, seed)), O89(vec2(seed, frame + 3.7))) - 0.5) * (0.3 + 4.0 * (1.0 - a)) * u;
vec2 q = O93(g, gui, mix(1.8, 1.0, O85(a))) + shake;
float burst = floor(time * 9.0);
float glitch = step(0.84, O89(vec2(burst, 4.2)));
q.x += glitch * (O89(vec2(floor(g.p.y / (2.0 * u)), burst)) - 0.5) * 5.0 * u;
float shown = smoothstep(0.0, 0.7, a) * 1.05;
if (O89(floor((q - g.tl) / u) + seed * 7.0) > shown) return vec4(0.0);
float v = clamp((q.y - g.tl.y) / (g.br.y - g.tl.y), 0.0, 1.0);
vec3 tone = mix(clamp(colour * 1.1 + 0.08, 0.0, 1.0), colour * 0.5, v);
tone = mix(tone, vec3(1.0, 0.86, 0.86), pow(1.0 - a, 3.0));
float grown = smoothstep(0.3, 1.0, a);
float body = O7f(g, q);
float drip = body > 0.0 ? 0.0 : O82(g, q, grown, time);
vec4 result = vec4(body > 0.0 ? tone : colour * 0.45, max(body, drip));
if (glitch > 0.0) {
vec4 cyan = vec4(0.1, 0.9, 0.9, O7f(g, q + vec2(1.5 * u, 0.0)) * 0.5);
vec4 red = vec4(1.0, 0.1, 0.15, O7f(g, q - vec2(1.5 * u, 0.0)) * 0.5);
result = O8e(result, O8e(red, cyan));
}
float shadow = max(O7f(g, q - vec2(u)), body > 0.0 ? 0.0 : O82(g, q - vec2(u), grown, time));
return O8e(result, vec4(0.08, 0.0, 0.0, shadow * 0.8));
}
#define O4e 0.45
#define O4d 2.5
float O98(float a, vec2 gui, float u, float span, float y) {
float lean = 5.0 * u * O4e;
float reach = span > 0.0 ? span * u * 0.5 : gui.x * 0.5 + O3a;
float start = gui.x * 0.5 - reach - lean;
float travel = 2.0 * (reach + lean) + O4d * 2.0 * u;
float titleMiddle = gui.y * 0.5 - 7.0 * u;
return start + smoothstep(0.0, 1.0, a) * travel + (titleMiddle - y) * O4e;
}
vec4 O92(float across) {
float shade = 0.62 + 0.38 * sin(across * O3f);
shade += 0.3 * exp(-pow((across - 0.32) / 0.09, 2.0));
float rim = smoothstep(0.0, 0.1, across) * (1.0 - smoothstep(0.9, 1.0, across));
return vec4(clamp(O4a * shade * mix(0.7, 1.0, rim), 0.0, 1.0), 1.0);
}
bool O96(TfxGlyph g, vec2 p, bool plate) {
if (p.x >= g.tl.x && p.x < g.br.x) return true;
return !plate && p.x >= g.tl.x - g.u && p.x < g.tl.x;
}
vec4 O95(TfxGlyph g, vec3 colour, float a, vec2 gui, float time, bool plate, float span) {
float u = g.u;
vec2 p = g.p;
if (!O96(g, p, plate)) return vec4(0.0);
float line = O98(a, gui, u, span, p.y);
if (p.x >= line) {
float across = (p.x - line) / (2.0 * O4d * u);
bool shaped = plate ? O7f(g, p) > 0.0 : p.y >= g.tl.y && p.y < g.br.y;
return across < 1.0 && shaped ? O92(across) : vec4(0.0);
}
float body = O7f(g, p);
float edge = plate ? 0.0 : O80(g, p, u) * (1.0 - body);
float shine = O94(p, gui, u, time);
vec3 face = colour + shine * 0.22;
vec3 rim = O4a + shine * 0.04;
vec4 result = vec4(clamp(body > 0.0 ? face : rim, 0.0, 1.0), max(body, edge));
if (!plate) {
vec2 dropped = p - vec2(0.0, 1.5 * u);
float shadow = max(O7f(g, dropped), O80(g, dropped, u)) * 0.38;
result = O8e(result, vec4(0.0, 0.0, 0.0, shadow));
}
result.rgb *= 1.0 - 0.3 * exp(-(line - p.x) / (1.5 * u));
return result;
}
vec4 O97(TfxGlyph g, vec3 colour, float a, vec2 gui, float time, float span) {
if (g.p.x >= O98(a, gui, g.u, span, g.p.y) || g.p.x < g.tl.x || g.p.x >= g.br.x + g.u) return vec4(0.0);
vec3 tone = colour + O94(g.p, gui, g.u, time) * 0.22;
vec4 texel = O99(g, g.p);
return vec4(clamp(tone * texel.rgb, 0.0, 1.0), step(0.1, texel.a));
}
#define O38 vec3(1.0, 0.96, 0.52)
#define O37 vec3(1.0, 0.72, 0.0)
#define O39 vec3(1.0)
#define O36 1.5
#define O35 1.5
vec4 O8b(TfxGlyph g, vec2 q, float edge, float sung) {
vec4 texel = O99(g, q);
float body = step(0.1, texel.a);
float v = clamp((q.y - g.tl.y) / max(g.br.y - g.tl.y, 1e-5), 0.0, 1.0);
vec3 gold = mix(O38, O37, v);
vec3 white = O39 * mix(1.0, 0.86, v);
float wipe = clamp((edge - q.x) / (O35 * g.u) + 0.5, 0.0, 1.0) * sung;
return vec4(mix(white, gold, wipe) * texel.rgb, body);
}
vec4 O8a(TfxGlyph g, float a, vec2 gui, float time, float extra) {
float fill = extra / 255.0;
float u = g.u;
float singing = fill > 0.0 && fill < 1.0 ? 1.0 : 0.0;
float lift = sin(fill * O3f) * O36 * u * singing;
vec2 q = g.p + vec2(0.0, lift);
float width = g.br.x - g.tl.x;
float edge = g.tl.x + fill * width;
float sung = fill > 0.0 ? 1.0 : 0.0;
vec4 letter = O8b(g, q, edge, sung);
float shine = O94(q, gui, u, time) * sung * step(q.x, edge);
letter.rgb = clamp(letter.rgb + shine * 0.25, 0.0, 1.0);
float halo = O80(g, q, u) * (1.0 - letter.a) * step(q.x, edge + u) * sung;
float pulse = 0.22 + 0.12 * singing * (0.5 + 0.5 * sin(time * 9.0));
vec4 glow = vec4(O37, halo * pulse);
vec2 dropped = q - vec2(u);
vec3 shadowTone = mix(vec3(0.24), O37 * 0.25, step(dropped.x, edge) * sung);
vec4 shadow = vec4(shadowTone, O7f(g, dropped));
vec4 result = O8e(letter, O8e(shadow, glow));
result.a *= a;
return result;
}
vec4 O90(int style, TfxGlyph g, vec3 colour, float a, vec2 gui, float time, float extra) {
int effect = style - O4f;
a = clamp(a, 0.0, 1.0);
vec4 result = vec4(0.0);
if (effect == O2e || effect == O50 || effect == O51 || effect == O42) {
float strength = TFX_INTENSITY[clamp(int(extra + 0.5), 0, 3)];
if (effect == O2e) result = O7c(g, colour, time, strength);
else if (effect == O50) result = O9a(g, colour, time, strength);
else if (effect == O51) result = O9b(g, colour, time, strength);
else result = O91(g, colour, time, strength);
result.a *= a;
} else if (effect == O2f) {
result = O7e(g, colour, a, gui, time);
} else if (effect == O32) {
result = O86(g, colour, gui, time);
result.a *= a;
} else if (effect == O30) {
result = O81(g, colour, a, gui, time);
} else if (effect == O49) {
result = O95(g, colour, a, gui, time, false, 0.0);
} else if (effect == O4b) {
result = O95(g, colour, a, gui, time, true, extra);
} else if (effect == O4c) {
result = O97(g, colour, a, gui, time, extra);
} else if (effect == O34) {
result = O8a(g, a, gui, time, extra);
}
return result;
}
#endif
#endif
