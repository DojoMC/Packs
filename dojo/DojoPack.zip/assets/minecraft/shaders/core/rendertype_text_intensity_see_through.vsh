#version 330
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#define O0 248
#define O1 252
in vec3 Position;
in vec4 Color;
in vec2 UV0;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
vec4 O53(vec4 colour) {
ivec3 rgb = ivec3(round(colour.rgb * 255.0));
if ((rgb.r & O1) != O0) {
return colour;
}
return vec4(vec3(float(rgb.g & 15), float(rgb.b >> 4), float(rgb.b & 15)) / 15.0, colour.a);
}
void main() {
gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
sphericalVertexDistance = fog_spherical_distance(Position);
cylindricalVertexDistance = fog_cylindrical_distance(Position);
vertexColor = O53(Color);
texCoord0 = UV0;
}
